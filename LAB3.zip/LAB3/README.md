----------------------------------------------------------------------------------
-- Course: ENSC462
-- Group #: 9 
-- Engineer: Valeriya Svichkar and Bing Qiu Zhang

-- Lab 3
-- README.md
----------------------------------------------------------------------------------

This folder includes the code for Lab2B.

To simulate on ModelSim:
	- Open project files in modelsim folder > top or spi_master.
	- in the Transcript window, type "do run.do wave"

This folder also contains the zipped Vivado project folder, vitis workspace, and code required to run on an FPGA board using Vivado/Vitis.
